package Proxypattern;

public interface Image {

	void display();
}
