package annotations_basics.parts;

public class CamBattery {

	public CamBattery() {
	}

	public String givePower() {
		return "Powered by Duracell";
	}

}
