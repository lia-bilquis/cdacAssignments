package annotations_basics.parts;

public class Lens {

	public String shutter() {
		return "Shutter closed and opened!";
	}

}
