package basics;

public class SinglyLL implements LL {

	public boolean Add(int x) {
		System.out.println("SinglyLL::Add() not yet implemented");
		return true;
	}

	public int[] transverse() {
		// TODO Auto-generated method stub
		System.out.println("SinglyLL::transverse() not yet implemented");
		return null;
	}

	public boolean remove() {
		// TODO Auto-generated method stub
		System.out.println("SinglyLL::transverse() not yet implemented");
		return false;
	}

}
