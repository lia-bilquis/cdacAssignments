package basics;

public interface LL {
	public boolean Add(int x);

	public int[] transverse();

	public boolean remove();
}
