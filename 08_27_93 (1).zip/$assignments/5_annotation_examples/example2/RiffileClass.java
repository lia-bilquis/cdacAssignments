package annotationExp;

public class RiffileClass {

	public RiffileClass() {
		
		// TODO Auto-generated constructor stub
		System.out.println("ctor of riffile class i.e. object is created by spring using annotation");
	}

}
