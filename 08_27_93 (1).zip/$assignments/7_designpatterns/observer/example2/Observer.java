package Observer;

public abstract class Observer {

	protected Subject subject;
	   public abstract void update();
	/*public void update() {
		// TODO Auto-generated method stub
		
	}*/
}
