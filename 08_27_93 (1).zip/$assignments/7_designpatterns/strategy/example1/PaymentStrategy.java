package strategy.demo1;

public interface PaymentStrategy {

	public void pay(int amount);
}