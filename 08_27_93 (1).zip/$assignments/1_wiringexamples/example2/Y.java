package basics;

public class Y {

	public Y() {
		System.out.println("Y object created!!");
	}

	/**
	 * 
	 * @return String
	 */
	public String dofun() {
		// TODO Auto-generated method stub
		return "y did this function for you <3";
	}

}
