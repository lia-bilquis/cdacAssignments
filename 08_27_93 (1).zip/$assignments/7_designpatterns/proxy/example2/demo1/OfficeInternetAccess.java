package proxydesign.demo1;


public interface OfficeInternetAccess {
	
	public void grantInternetAccess();

}
