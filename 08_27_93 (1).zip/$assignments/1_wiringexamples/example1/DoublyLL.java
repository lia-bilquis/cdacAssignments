package basics;

public class DoublyLL implements LL {

	public boolean Add(int x) {
		System.out.println("Add not yet implemented");
		return true;
	}

	public int[] transverse() {
		// TODO Auto-generated method stub
		System.out.println("transverse not yet implemented");
		return null;
	}

	public boolean remove() {
		// TODO Auto-generated method stub
		System.out.println("transverse not yet implemented");
		return false;
	}

}
